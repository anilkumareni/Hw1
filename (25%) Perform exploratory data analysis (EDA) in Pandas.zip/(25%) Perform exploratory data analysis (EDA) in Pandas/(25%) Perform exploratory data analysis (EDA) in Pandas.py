#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Import the pandas library and alias it as 'pd'
import pandas as pd
# Read a CSV file named "DRYAD_Data_Johansson.csv" into a DataFrame and store it in the variable 'data'
data = pd.read_csv("DRYAD_Data_Johansson.csv")
# Print the 'data' DataFrame to display its contents
data


# In[2]:


# To obtain information about the 'data' DataFrame.
data.info()


# In[3]:


# Summary statistics
summary_stats = data.describe()
summary_stats


# In[4]:


# Check for missing values
missing_values = data.isnull().sum()
missing_values


# # § Task: What are the top 5 species detected over the entire dataset?
# 

# In[5]:


# Group the data by the "Species Detected" column and count the occurrences
species_counts = data.groupby("Species Detected").size().reset_index(name="Count")

# Sort the species by count in descending order
top_species = species_counts.sort_values(by="Count", ascending=False).head(5)

# Display the top 5 species detected
print(top_species)


# In[6]:


import seaborn as sns
import matplotlib.pyplot as plt

# Create a vertical bar plot
plt.figure(figsize=(8, 6))
sns.barplot(x="Species Detected", y="Count", data=top_species)
plt.title("Top 5 Species Detected")
plt.xlabel("Species Detected")
plt.ylabel("Count")
plt.xticks(rotation=45)  

# Show the plot
plt.show()


# # § Task: Which 5 species over all data are most frequent at midnight (12am)?

# In[7]:


# Convert the "Time of Detection" column to datetime
data['Time of Detection'] = pd.to_datetime(data['Time of Detection'])

# Filter the data for detections at midnight (12am)
midnight_data = data[data['Time of Detection'].dt.hour == 0]

# Group the data by "Species Detected" and "Time of Detection" and count the occurrences
species_counts_at_midnight = midnight_data.groupby(["Species Detected", "Time of Detection"]).size().reset_index(name="Count")

# Find the top 5 species with the highest counts at midnight
top_species_at_midnight = species_counts_at_midnight.groupby("Species Detected")["Count"].sum().nlargest(5)

# Display the top 5 species detected at midnight
print(top_species_at_midnight)


# In[8]:


import seaborn as sns
import matplotlib.pyplot as plt

# Create a bar plot
plt.figure(figsize=(10, 6))
sns.barplot(x=top_species_at_midnight.index, y=top_species_at_midnight.values)
plt.title("Top 5 Species Detected at Midnight (12am)")
plt.xlabel("Species Detected")
plt.ylabel("Count")
plt.xticks(rotation=45)  # Rotate x-axis labels for better readability

# Show the plot
plt.show()


# # § Task: Use the library sns.heatmap() to generate a heatmap with Species Detected on the 𝑦-axis and Hour of Detection on the 𝑥-axis.

# In[9]:


import seaborn as sns
import matplotlib.pyplot as plt

# Extract the hour of detection from the 'Time of Detection' column
data['Time of Detection'] = pd.to_datetime(data['Time of Detection'])
data['Hour of Detection'] = data['Time of Detection'].dt.hour

# Pivot the data to create a table for the heatmap
heatmap_data = data.pivot_table(index='Species Detected', columns='Hour of Detection', values='Number of the Species Detected in the Photo', aggfunc='sum', fill_value=0)

# Create the heatmap
plt.figure(figsize=(12, 8))
sns.heatmap(heatmap_data, cmap='YlGnBu', annot=True, fmt='d', linewidths=0.5, cbar=True)
plt.title('Species Detected by Hour of Detection')
plt.xlabel('Hour of Detection')
plt.ylabel('Species Detected')

# Show the heatmap
plt.show()


# # § Task: Compare the result of your prior answer with running heatmap() with the robust=True parameter. Which of the two output graphs looks more interpretable ?
# 

# In[10]:


import seaborn as sns
import matplotlib.pyplot as plt
# Create the heatmap with robust=True
plt.figure(figsize=(12, 8))
sns.heatmap(heatmap_data, cmap='YlGnBu', annot=True, fmt='d', linewidths=0.5, cbar=True, robust=True)
plt.title('Species Detected by Hour of Detection (Robust=True)')
plt.xlabel('Hour of Detection')
plt.ylabel('Species Detected')
plt.show()


# # § Task: Compute the mode of all species in the dataset

# In[11]:


# Calculate the mode of all species
species_mode = data["Species Detected"].mode()

# Display the mode of all species
print("Mode of all species:", species_mode)


# # § Task: Compute the probabilities of all species, but make two columns: (1) with those in the group with forest density < 0.3 and (2) those with forest density ≥ 0.3. Label them “urban” and “rural”.

# In[12]:


# Define the forest density threshold
threshold = 0.3

# Create a new column 'Category' based on forest density
data['Category'] = data['Forest Cover within 400m of camera (km^2)'].apply(lambda x: 'urban' if x >= threshold else 'rural')

# Calculate the probabilities of each species within each category
probs = data.groupby(['Category', 'Species Detected']).size() / data.groupby('Category').size()
probs = probs.reset_index(name='Probability')

# Pivot the DataFrame to get the desired format
probs_pivot = probs.pivot(index='Species Detected', columns='Category', values='Probability').reset_index()

# Rename the columns for better clarity
probs_pivot.columns.name = None
probs_pivot.columns = ['Species Detected', 'rural', 'urban']

# Print the resulting DataFrame
print(probs_pivot.to_string(index=False))


# In[ ]:





# In[ ]:




